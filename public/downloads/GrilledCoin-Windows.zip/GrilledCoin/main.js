const { app, BrowserWindow, shell, Menu } = require("electron");
const fs = require("fs");
const path = require("path");

// The GrilledCoin web app this desktop client connects to.
// Change it by editing config.json next to this file, or set GRILLEDCOIN_URL.
let serverUrl = process.env.GRILLEDCOIN_URL || "https://coin.up.railway.app";
try {
  const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "config.json"), "utf8"));
  if (cfg && cfg.serverUrl) serverUrl = cfg.serverUrl;
} catch { /* use default */ }

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 820,
    minWidth: 380,
    minHeight: 600,
    backgroundColor: "#0a1218",
    title: "GrilledCoin",
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true },
  });

  win.loadURL(serverUrl);

  // Keep in-app navigation inside the window; send outbound links
  // (Patreon, Stripe checkout, etc.) to the system browser.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(serverUrl)) {
      shell.openExternal(url);
      return { action: "deny" };
    }
    return { action: "allow" };
  });
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
