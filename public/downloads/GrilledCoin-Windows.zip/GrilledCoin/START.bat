@echo off
title GrilledCoin
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js isn't installed yet - installing it automatically...
  echo.
  where winget >nul 2>nul
  if errorlevel 1 (
    echo  Could not find winget on this PC.
    echo  Please install Node.js manually from https://nodejs.org  ^(LTS version^), then run START.bat again.
    echo.
    pause
    exit /b 1
  )
  winget install --id OpenJS.NodeJS.LTS -e --silent --accept-package-agreements --accept-source-agreements
  echo.
  echo  Node.js is installed! Please close this window and double-click START.bat again.
  echo.
  pause
  exit /b 0
)

if not exist node_modules (
  echo Setting up GrilledCoin for first launch... this can take a minute.
  call npm install
)

echo Launching GrilledCoin...
call npm start
