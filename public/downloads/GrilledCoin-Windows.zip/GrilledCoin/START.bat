@echo off
title GrilledCoin
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is required to run GrilledCoin.
  echo  Get it free from https://nodejs.org  ^(LTS version^), then run START.bat again.
  echo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo Setting up GrilledCoin for first launch... this can take a minute.
  call npm install
)

echo Launching GrilledCoin...
call npm start
