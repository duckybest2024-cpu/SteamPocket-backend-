#!/bin/bash
# macOS / Linux launcher for GrilledCoin
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required. Install it from https://nodejs.org then run again."
  exit 1
fi
[ -d node_modules ] || npm install
npm start
