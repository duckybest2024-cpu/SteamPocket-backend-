GrilledCoin — Desktop App
=========================

A native desktop window for GrilledCoin — no browser tabs, no address bar,
just the casino in its own app window.

HOW TO RUN
----------
Windows:  double-click  START.bat
Mac/Linux: run          ./START.command   (or:  npm install && npm start)

The first launch downloads what it needs (about a minute). After that it
opens instantly.

REQUIREMENTS
------------
- Node.js 18 or newer (free): https://nodejs.org  (install the "LTS" build)
- An internet connection (the app connects to the live GrilledCoin servers)

CHANGE THE SERVER
-----------------
Edit config.json and set "serverUrl" to your GrilledCoin address.

Windows SmartScreen note: if Windows warns about the script, choose
"More info" -> "Run anyway". The launcher only installs Electron and opens
the GrilledCoin window.
