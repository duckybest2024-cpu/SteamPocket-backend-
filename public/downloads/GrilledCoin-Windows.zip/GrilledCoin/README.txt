GrilledCoin — Desktop App
=========================

A native desktop window for GrilledCoin — no browser tabs, no address bar,
just the casino in its own app window.

STEP 1: EXTRACT THE ZIP
------------------------
Windows shows this folder inside a "Compressed (zipped) Folder" — you can't
run anything from inside that view. Right-click the downloaded zip and choose
"Extract All...", then open the extracted folder (the one WITHOUT the zipper
icon) before continuing.

STEP 2: RUN THE LAUNCHER
-------------------------
Windows:   double-click  START.bat
Mac/Linux: run           ./START.command   (or:  npm install && npm start)

If Node.js isn't installed yet, START.bat will install it for you
automatically (using Windows' built-in winget tool), then ask you to run
START.bat one more time. After that it opens instantly.

REQUIREMENTS
------------
- Windows 10/11, macOS, or Linux
- An internet connection (the app connects to the live GrilledCoin servers)

CHANGE THE SERVER
-----------------
Edit config.json and set "serverUrl" to your GrilledCoin address.

Windows SmartScreen note: if Windows warns about the script, choose
"More info" -> "Run anyway". The launcher only installs Node.js/Electron and
opens the GrilledCoin window.
